# 14 Bank Undo with LinkedStack

This folder contains the complete Java source file(s) for this example.

## Files
- `Node.java`
- `LinkedStack.java`
- `UndoDepositLinkedDemo.java`

See `OUTPUT.txt` for the expected output.
