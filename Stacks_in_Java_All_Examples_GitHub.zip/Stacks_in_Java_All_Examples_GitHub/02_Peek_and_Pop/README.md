# 02 Peek and Pop

This folder contains the complete Java source file(s) for this example.

## Files
- `Main.java`

See `OUTPUT.txt` for the expected output.
