# Stacks in Java — All Examples

This repository contains the 15 Java examples from the **Stacks in Java — All Examples** notes.

## Contents

Each example is kept in its own folder so it can be opened and reviewed separately.

1. Push and Print
2. peek() and pop()
3. Generics: Box
4. Bank: Undo Deposit
5. Student: Undo Course
6. Reversing a String
7. ArrayStack Implementation
8. ArrayStack Trace
9. Custom Exception
10. Linked List Traversal
11. Insert at the Front
12. Node and LinkedStack Implementation
13. LinkedStack Trace
14. Bank Undo with LinkedStack
15. Student Undo Course with LinkedStack

## How to use

1. Open the folder for the example you want.
2. Open the `.java` files to read the code.
3. Run the file that contains `public static void main(String[] args)`.
4. Compare the result with `OUTPUT.txt`, when provided.

For examples that use `Node.java`, `LinkedStack.java`, or `ArrayStack.java`, keep all the required files in the same folder when compiling.

## Requirements

- Java JDK 8 or newer
- Any Java editor or IDE, such as IntelliJ IDEA or VS Code

## Compile and run example

Open a terminal in the example folder, then run:

```bash
javac Main.java
java Main
```

For examples with multiple Java files, compile all files:

```bash
javac *.java
```

Then run the class containing `main`, for example:

```bash
java LinkedStackTraceDemo
```
