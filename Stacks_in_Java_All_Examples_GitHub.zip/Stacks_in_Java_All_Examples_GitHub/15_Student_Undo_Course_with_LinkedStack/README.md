# 15 Student Undo Course with LinkedStack

This folder contains the complete Java source file(s) for this example.

## Files
- `Node.java`
- `LinkedStack.java`
- `UndoCourseLinkedDemo.java`

See `OUTPUT.txt` for the expected output.
