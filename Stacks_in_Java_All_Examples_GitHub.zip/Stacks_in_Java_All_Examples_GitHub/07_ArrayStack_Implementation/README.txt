This folder contains the ArrayStack implementation. It is a reusable class, so compile it with a separate test/demo class to run it.
