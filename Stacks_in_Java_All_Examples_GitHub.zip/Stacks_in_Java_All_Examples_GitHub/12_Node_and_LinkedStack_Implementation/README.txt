This folder contains the two reusable classes used by LinkedStack examples: Node<T> and LinkedStack<T>.
