# 08 ArrayStack Trace

This folder contains the complete Java source file(s) for this example.

## Files
- `ArrayStackTraceDemo.java`
- `ArrayStack.java`

See `OUTPUT.txt` for the expected output.
