# 13 LinkedStack Trace

This folder contains the complete Java source file(s) for this example.

## Files
- `Node.java`
- `LinkedStack.java`
- `LinkedStackTraceDemo.java`

See `OUTPUT.txt` for the expected output.
