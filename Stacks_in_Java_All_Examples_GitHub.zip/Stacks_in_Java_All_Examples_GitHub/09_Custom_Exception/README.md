# 09 Custom Exception

This folder contains the complete Java source file(s) for this example.

## Files
- `EmptyCollectionException.java`
- `Main.java`

See `OUTPUT.txt` for the expected output.
